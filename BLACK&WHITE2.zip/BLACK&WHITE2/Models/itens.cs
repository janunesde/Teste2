namespace BLACK_WHITE.Models
{
    public class itens
    {
      
public string Nome;
public string cidade;
public string  bairro;
public string  numero;

public string pedido;
public string Bebida;

public int Quantidade;

public string Descricao;
public string Skol;
    }
}