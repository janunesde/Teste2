namespace Atividade2.Models
{
    public class Pacote
    {
        public int Id {get; set;}
        public string Nome {get; set;}
        public string Origem {get; set;}
        public string Destino {get; set;}
        public string Atrativos {get; set;}
        public string Saida {get; set;}
        public string Retorno {get; set;}
        public int Usuario {get; set;}

    }
}